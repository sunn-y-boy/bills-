package com.sxt.sys.mapper;

import com.sxt.sys.domain.Billtype;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author 老雷
 * @since 2019-09-20
 */
public interface BilltypeMapper extends BaseMapper<Billtype> {

}
