package com.sxt.sys.controller;


import java.io.IOException;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.DigestUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.sxt.common.ResultObj;
import com.sxt.sys.domain.User;
import com.sxt.sys.service.UserService;

import cn.hutool.captcha.CaptchaUtil;
import cn.hutool.captcha.CircleCaptcha;
import org.springframework.util.StringUtils;

/**
 * <p>
 *  前端控制器
 *  登陆控制
 * </p>
 *
 * @author 老雷
 * @since 2019-09-20
 */
@Controller
@RequestMapping("/login")
public class LoginController {
	
	@Autowired
	private UserService userService;
	
	/**
	 * 跳转到登陆页面
	 */
	@RequestMapping("toLogin")
	public String toLogin() {
		return "login";
	}
	
	@RequestMapping("login")
	@ResponseBody
	public ResultObj login(String loginname,String pwd,String code,HttpSession session) {
		Object codeSession = session.getAttribute("captcha_code");
		System.out.println("验证码为: "+codeSession);
		if(code!=null&&code.equals(codeSession)) {

			QueryWrapper<User> queryWrapper=new QueryWrapper<>();
			queryWrapper.eq("loginname", loginname);
			queryWrapper.eq("pwd", pwd);
			User user = userService.getOne(queryWrapper);
			System.out.println(user);
			if(null!=user) {
				session.setAttribute("user", user);
				return new ResultObj(200, "登陆成功");
			}else {
				return new ResultObj(-1, "用户名或密码不正确");
			}
		}else {
			return new ResultObj(-1, "验证码错误");
		}

	}
//数据库中的密码存储时无加密
//	public ResultObj login(String loginname, String pwd, String code, HttpSession session) {
//		Object codeSession = session.getAttribute("captcha_code");
//		if (code != null && code.equals(codeSession)) {
//			if (StringUtils.isEmpty(pwd)) {
//				return new ResultObj(-1, "密码不能为空");
//			}
//
//			String encryptedPwd = DigestUtils.md5DigestAsHex(pwd.getBytes()); // 使用MD5加密密码
//			QueryWrapper<User> queryWrapper = new QueryWrapper<>();
//			queryWrapper.eq("loginname", loginname).eq("pwd", encryptedPwd);
//			User user = userService.getOne(queryWrapper);
//
//			if (user != null) {
//				session.setAttribute("user", user);
//				return new ResultObj(200, "登录成功");
//			} else {
//				return new ResultObj(-1, "用户名或密码不正确");
//			}
//		} else {
//			return new ResultObj(-1, "验证码错误");
//		}
//	}

	@RequestMapping("getCode")
	public void getCode1(HttpServletResponse resp, HttpSession session) throws IOException {
		CircleCaptcha captcha = CaptchaUtil.createCircleCaptcha(116, 36, 4, 3);
		// 获取验证码字符串
		String code = captcha.getCode();
		System.out.println("生成的验证码：" + code);
		// 将验证码字符串存入 session
		session.setAttribute("captcha_code", code);
		//System.out.println("code: "+session.getAttribute("captcha_code"));
		resp.setContentType("image/png");
		try (ServletOutputStream outputStream = resp.getOutputStream()) {
			// 将验证码图片写入响应输出流
			captcha.write(outputStream);
			outputStream.flush();
		} catch (IOException e) {
			System.out.println("验证码图片写入响应流失败：" + e.getMessage());
			throw e;
		}
	}
}

